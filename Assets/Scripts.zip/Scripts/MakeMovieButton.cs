﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeMovieButton : MonoBehaviour
{
	// OnMouseUp is called when the user has released the mouse button.
	protected void OnMouseUp()
	{
		Debug.Log("click");
	}
}
