﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MovieTitles
{
	public string[] comedy;
	public string[] drama;
	public string[] horror;
	public string[] musical;
	public string[] western;
	public string[] action;
}
